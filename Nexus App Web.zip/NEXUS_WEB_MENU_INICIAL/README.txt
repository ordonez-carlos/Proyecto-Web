N.E.X.U.S. WEB - MENÚ PRINCIPAL MEJORADO

Abra index.html con Google Chrome, Microsoft Edge o Firefox.

La pantalla principal conserva el estilo de portal solicitado, con:
- Barra superior con logo e inicio de sesión.
- Presentación Campus Inteligente.
- Accesos rápidos a Ranking General y Cuadro de Honor.
- Menú principal completo.

El resto de la aplicación se mantiene sin cambios.

Usuario estudiante: juan01 / JP001
Usuario profesor: rsucuy / RS2026

CAMBIOS DE ESTA VERSION
- Se eliminaron los botones de la parte superior de la pantalla principal.
- El titulo grande 'Campus Inteligente' fue reemplazado por 'N.E.X.U.S.'.
- El resto de la aplicacion se mantiene sin cambios.

MEJORA DEL BOTON VOLVER
- El boton Volver ya no es fijo.
- Ahora aparece al final de cada apartado publico y se mueve con la pagina.
- Usa un estilo similar al boton Cerrar Sesion.
- Se elimino de los paneles de estudiante y profesor.

FONDO DE PARTICULAS
- Se agregó un fondo animado de partículas y conexiones luminosas.
- Está disponible en el menú principal, secciones públicas y paneles de usuario.
- No bloquea botones ni formularios.
- Se desactiva automáticamente si el navegador tiene reducción de movimiento activada.

MEJORAS DEL MENU PRINCIPAL
- Las partículas ahora son visibles en la pantalla principal.
- Se eliminó el botón superior Cuadro de Honor del bloque de presentación.
- Las cinco opciones inferiores tienen iconos SVG, colores diferenciados y mejor interacción.
- El resto del sistema se mantiene sin cambios.
